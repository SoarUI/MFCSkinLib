#pragma once
/********************************************************************
    Descibe:      ���崦�����Ļ���
    created:      2012/9/19 19:11
    FullName:     ..\MYFeel\TFeelMouseCallee.h
    Path:         ..\MYFeel\MYFeel
    ClassName:    TFeelMouseCallee
    FileType:     h
    Author:       nicklisir@163.com
    NeededLib:    
    requires:      
*********************************************************************/
#include "TFeelMouseEvent.h"
class TFeelMouseCallee 
{
public:
	TFeelMouseCallee(void){;}
public:
	virtual ~TFeelMouseCallee(void){;}
	virtual bool Process(const TFeelMouseEvent* evt)
	{
		(evt);
		return true;
	}
};
