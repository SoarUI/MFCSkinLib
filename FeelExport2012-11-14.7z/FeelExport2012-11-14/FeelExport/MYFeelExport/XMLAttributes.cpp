
#include "XMLAttributes.h"

#include <sstream>

#include <iterator>

#include <tchar.h>


XMLAttributes::XMLAttributes(void)
    
{
}

    
XMLAttributes::~XMLAttributes(void)
    
{
}

    
void XMLAttributes::add(const GString& attrName, const GString& attrValue)
   
{
        
   d_attrs[attrName] = attrValue;
    
}

    
void XMLAttributes::remove(const GString& attrName)
    
{
        
   AttributeMap::iterator pos = d_attrs.find(attrName);

        
   if (pos != d_attrs.end())
            
     d_attrs.erase(pos);
    
}

    
bool XMLAttributes::exists(const GString& attrName) const
    
{
        
    return d_attrs.find(attrName) != d_attrs.end();
    
}

    
size_t XMLAttributes::getCount(void) const
    
{
        
   return d_attrs.size();
   
 }

    
const GString XMLAttributes::getName(size_t index) const
    
{
        
   if (index >= d_attrs.size())
        
   {
           
      return GString(_T(""));
        
    }

        
   AttributeMap::const_iterator iter = d_attrs.begin();
        
   std::advance(iter, index);

        
   return (*iter).first;
    
}

    
const GString XMLAttributes::getValue(size_t index) const
    
{
        
   if (index >= d_attrs.size())
        
   {
            
      return GString(_T(""));
        
   }

        
   AttributeMap::const_iterator iter = d_attrs.begin();
        
   std::advance(iter, index);

        
   return (*iter).second;
    
}

    
const GString XMLAttributes::getValue(const GString& attrName) const
    
{
        
  AttributeMap::const_iterator pos = d_attrs.find(attrName);

        
  if (pos != d_attrs.end())
        
  {
            
    return (*pos).second;
        
  }
        
  else
        
  {
          
    return GString(_T(""));
        
  }
    
}

  
const GString XMLAttributes::getValueAsString(const GString& attrName, const GString& def)const
    
{
        
    return (exists(attrName)) ? getValue(attrName) : def;
    
}


    
bool XMLAttributes::getValueAsBool(const GString& attrName, bool def) const
    
{
        
   if (!exists(attrName))
        
   {
            
     return def;
        
   }

        
   const GString& val = getValue(attrName);

        
   if (val == _T("false") || val == _T("0"))
        
   {
            
     return false;
        
   }
        
   else if (val == _T("true") || val == _T("1"))
        
   {
            
     return true;
        
    }
        
   else
        
   {
           
     return def;
        
    }
    
}

    
int XMLAttributes::getValueAsInteger(const GString& attrName, int def) const
    
{
        
   if (!exists(attrName))
        
   {
            
     return def;
        
   }

        
   int val;
        
   val =_ttoi(getValue(attrName).c_str());
        
   return val;
    
}

    
float XMLAttributes::getValueAsFloat(const GString& attrName, float def) const
    
{
        
   if (!exists(attrName))
        
   {
            
     return def;
        
   }

        
   float val;
        
   val =_tstof(getValue(attrName).c_str());

       
   return val;
    
}

