#ifndef _RawDataContainerBase_h_
#define _RawDataContainerBase_h_
class RawDataContainerBase
{
public:
	RawDataContainerBase(void){}
	virtual ~RawDataContainerBase(void){}
	virtual void setData(TCHAR* data) =0;
	virtual TCHAR* getDataPtr(void) =0 ;
	virtual TCHAR* getDataPtr(void)const =0 ;
	virtual void setSize(size_t size)=0;
	virtual size_t getSize(void)const =0;
};
#endif