#ifndef _FeelEvent_DATASTRUCT_H_
#define _FeelEvent_DATASTRUCT_H_
typedef enum UtgFeelEventID
{
	MouseEventType,
	KeyEventType,
} FeelEventID,*FeelEventIDPtr;
typedef enum UtgFeelMouseEventID
{
	MouseUnknown=0,
	LeftButtonDown,
	RightButtonDown,
	MidButtonDown,
	LeftButtonUp,
	RightButtonUp,
	MidButtonUp,
} FeelMouseEventID,*FeelMouseEventIDPtr;
#endif