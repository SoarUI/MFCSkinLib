#pragma once
#include "tfeeleventabstract.h"
class TFeelMouseEvent :
	public TFeelEventAbstract
{
public:
	TFeelMouseEvent(void){d_EventID=MouseEventType;}
	TFeelMouseEvent(HWND hwnd,GString look,GString comp,POINT pos,UtgFeelMouseEventID mouseEventid):
		d_owner(hwnd),d_MouseID(mouseEventid),
		d_look(look),d_component(comp),d_pos(pos){}
public:
	virtual ~TFeelMouseEvent(void){}
	HWND getOwner(void) const{return d_owner;}
	UtgFeelMouseEventID d_MouseID;
	GString d_look;
	GString d_component;
	HWND d_owner;
	POINT d_pos;

};
