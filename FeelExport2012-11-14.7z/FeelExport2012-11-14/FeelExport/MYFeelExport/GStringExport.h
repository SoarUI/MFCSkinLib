#ifndef _GStringExport_h_
#define _GStringExport_h_
//#include "gdfmacro.h"//��ͯ����^_^���������
#include <Windows.h>
#include<malloc.h>
#include <tchar.h>
//string
#include <xstring>
typedef std::basic_string<TCHAR, std::char_traits<TCHAR>,std::allocator<TCHAR> > TSTRING;
class GString :
	public TSTRING
{
public:
	GString(void){}
	GString(const TCHAR* cstr)
	{
		TSTRING::assign(cstr);
	}
	GString(const GString& str)
	{
		TSTRING::assign(str.c_str());
	}
	GString(const TSTRING& str)
	{
		TSTRING::assign(str.c_str());
	}
public:
	virtual ~GString(void)
	{
		
	}
	//���ڱȽ�map/vector
	struct FastLessCompare
	{
		bool operator() (const GString& a, const GString& b) const
		{
			const size_t la = a.length();
			const size_t lb = b.length();
			if (la == lb)
				return ( a.compare(b.data() )<0 );
			return (la < lb);
		}
	};
	GString&	operator+=(const GString& str)
	{
		 TSTRING::append(str.c_str());
		 return *this;
	}
	GString&	operator+(const GString& str)
	{
		TSTRING::append(str);
		return *this;
	}
	GString&	operator+(const TCHAR* cstr)
	{
		TSTRING::append(cstr);
		return *this;
	}
	GString&	operator+=(const TSTRING& std_str)
	{
		TSTRING::append(std_str.c_str());
		 return *this;
	}
	GString&	operator+=(const TCHAR* cstr)
	{
		TSTRING::append(cstr, lstrlen(cstr));
		 return *this;
	}
	bool	operator!=(const TCHAR* cstr)
	{
		const size_t la= lstrlen(cstr);
		if (la==length())
		{
			return lstrcmpi(data(),cstr)!=0;
		}
		return la != length();
	}
	GString& append(const TCHAR* cstr)
	{
		 TSTRING::append(cstr);
		 return *this;
	}
	GString& append(const TCHAR* cstr,size_t len)
	{
		TSTRING::append(cstr, len);
		return *this;
	}
	GString substr(size_type _Off , size_type _Count )
	{
		return TSTRING::substr(_Off,_Count);
	}
	friend GString operator+(const GString &lhs, const GString& rhs)
	{ 
		GString tmp;
		tmp +=lhs;
		tmp+=rhs;
		return tmp;
	}
	friend GString operator+(const GString &lhs,  GString& rhs)
	{ 
		GString tmp;
		tmp +=lhs;
		tmp+=rhs;
		return tmp;
	}
	friend GString operator+(const GString &lhs, const TCHAR* rhs)
	{ 
		GString tmp;
		tmp +=lhs;
		tmp+=rhs;
		return tmp;
	}
	friend GString operator+(const GString &lhs,  TCHAR*rhs)
	{ 
		GString tmp;
		tmp +=lhs;
		tmp+=rhs;
		return tmp;
	}
	friend bool operator==(const GString &lhs,const TCHAR* rhs)
	{
		const size_t la = lstrlen(rhs);
		const size_t lb = lhs.length();
		if (la == lb)
			return ( lhs.compare(rhs )==0 );
		return false;
	}
	
	friend bool operator==(const GString &lhs,const GString& rhs)
	{
		const size_t la = rhs.length();
		const size_t lb = lhs.length();
		if (la == lb)
			return ( lhs.compare(rhs.data() )==0 );
		return false;
	}
};
#endif