﻿#ifndef _MYFeelModule_h_
#define _MYFeelModule_h_
#include "Export.h"
//mouseevt
#include "TFeelMouseCallee.h"
//Any
#include "ProviderAny.h"
class MYFeelModule
{
public:
	typedef BOOL   (__cdecl *FeelSystem_AUTOSKIN)(HWND hWnd, BOOL bSkined,INT Itheme) ;
	typedef BOOL   (__cdecl *FeelSystem_REGEXTENDCLASS)(TCHAR* newClass,WindType stdClassID) ;
	typedef BOOL   (__cdecl *FeelSystem_REGEXTENDCLASSFILE)(TCHAR* extFile);
	typedef BOOL   (__cdecl *FeelSystem_REMOVEEXTENDCLASS)(TCHAR* newClass);
	typedef INT   (__cdecl *FeelSystem_SETCSTHEME)(PureThemePtr lpTheme);
	typedef DWORD   (__cdecl *FeelSystem_LOOKNFEELSTART)(void);
	typedef DWORD   (__cdecl *FeelSystem_LOOKNFEELINIT)(const TCHAR * ConfigFile);
	typedef VOID (__cdecl *FeelSystem_LOOKNFEELEND)(void);
	typedef DWORD   (__cdecl *FeelSystem_GETTHEMES)(FeelList& outList);
	typedef DWORD   (__cdecl *FeelSystem_GETSURFACE)(FeelSurfaceList& outlist);
	typedef DWORD   (__cdecl *FeelSystem_CHANGETHEME)(const FeelTheme& theme) ;
	typedef DWORD   (__cdecl *FeelSystem_CHANGESURFACE)(const FeelSurface& theme) ;
	//customFeel
	typedef VOID   (__cdecl *FeelSystem_SETCSFEEL)(HWND hwnd,const TCHAR* pstrControl) ;
	typedef VOID   (__cdecl *FeelSystem_REMOVECSFEEL)(HWND hwnd) ;//
	//MouseEvent
	typedef DWORD   (__cdecl *FeelSystem_SETMOUSECALLEE)(HWND hwnd,const TCHAR* pstrControl,TFeelMouseCallee* Callee) ;
	typedef VOID   (__cdecl *FeelSystem_REMOVEMOUSECALLEE)(HWND hwnd) ;
	//ProviderAny
	typedef DWORD   (__cdecl *FeelSystem_REGISTERPROVIDERANY)(const TCHAR* plugName,const _ProviderKeyAny& KeyAny);
	typedef VOID   (__cdecl *FeelSystem_REMOVEPROVIDERANY)(const TCHAR* plugName);
	MYFeelModule(void)
	{
		ftrautoSkin        = NULL ;
		ftrRegExtendClass       = NULL ;
		ftrRegExtendClassFile       = NULL ;
		ftrRemoveExtendClass       = NULL ;
		ftrPureTheme   = NULL ;
		//FeelSystem
		ftrSystemInit      = NULL ;
		ftrSystemStart     = NULL ;
		ftrSystemEnd       = NULL ;
		ftrGetThemes     = NULL ;
		ftrGetSurfaces = NULL ;
		ftrChangeTheme= NULL ;
		ftrChangeSurface =NULL;
		ftrSetCSFeel    =NULL;
		ftrRemoveCSFeel =NULL;
		ftrSetCSFrameFeel =NULL;
		ftrSetCSMenuBarFeel =NULL;
		ftrSetCSScrollFeel =NULL;
		//
		ftrRemoveCSFrameFeel =NULL;
		ftrRemoveCSMenuBarFeel =NULL;
		ftrRemoveCSScrollFeel =NULL;
		ftrSetMouseCallee =NULL;
		ftrRemoveMouseCallee =NULL;
		//any
		ftrRemoveProviderAny =NULL;
		ftrRemoveProviderAny =NULL;
		m_hDll          = NULL ;
	}
	MYFeelModule(LPCTSTR DllPath )
	{
		ftrautoSkin        = NULL ;
		ftrRegExtendClass       = NULL ;
		ftrRegExtendClassFile       = NULL ;
		ftrRemoveExtendClass       = NULL ;
		ftrPureTheme   = NULL ;
		//FeelSystem
		ftrSystemInit      = NULL ;
		ftrSystemStart     = NULL ;
		ftrSystemEnd       = NULL ;
		ftrGetThemes     = NULL ;
		ftrGetSurfaces = NULL ;
		ftrChangeTheme= NULL ;
		ftrChangeSurface =NULL;
		ftrSetCSFeel    =NULL;
		ftrRemoveCSFeel =NULL;
		ftrSetCSFrameFeel =NULL;
		ftrSetCSMenuBarFeel =NULL;
		ftrSetCSScrollFeel =NULL;
		//
		ftrRemoveCSFrameFeel =NULL;
		ftrRemoveCSMenuBarFeel =NULL;
		ftrRemoveCSScrollFeel =NULL;
		ftrSetMouseCallee =NULL;
		ftrRemoveMouseCallee =NULL;
		//any
		ftrRemoveProviderAny =NULL;
		ftrRemoveProviderAny =NULL;
		m_hDll          = NULL ;
		Init(DllPath) ;
	};
public:

	virtual ~MYFeelModule(void)
	{
		if(m_hDll)
		{
			FreeLibrary(m_hDll) ;
		}
	}
	BOOL Init(LPCTSTR DllPath);
	BOOL   AutoSkin(HWND hWnd, BOOL bSkined,INT Itheme) {if(ftrautoSkin) return ftrautoSkin(hWnd,bSkined,Itheme) ;};
	BOOL   RegExtClass(TCHAR* newClass,WindType stdClassID) {if(ftrRegExtendClass) return ftrRegExtendClass(newClass,stdClassID) ;};
	BOOL   RegExtClassFile(TCHAR* extFile) {if(ftrRegExtendClassFile) return ftrRegExtendClassFile(extFile) ;};
	INT    RemoveExtClass(TCHAR* newClass) {if(ftrRemoveExtendClass) return ftrRemoveExtendClass(newClass) ;};
	DWORD   SetCsTheme(PureThemePtr lpTheme) {if(ftrPureTheme) return ftrPureTheme(lpTheme) ;};
	//
	DWORD   FeelStart(void) {if(ftrSystemStart) return ftrSystemStart() ;};
    DWORD   FeelInit(const TCHAR * ConfigFile) {if(ftrSystemInit) return ftrSystemInit(ConfigFile) ;};
	VOID    FeelEnd(void) {if(ftrSystemEnd) ftrSystemEnd() ;}
	//Theme-surface
	DWORD   FeelGetThemes(FeelList& outList) {if(ftrGetThemes) return ftrGetThemes(outList) ;};
	DWORD   FeelGetSurfaces(FeelSurfaceList& outlist) {if(ftrGetSurfaces) return ftrGetSurfaces(outlist) ;};
	DWORD   FeelChangeTheme(const FeelTheme& theme) {if(ftrChangeTheme) return ftrChangeTheme(theme) ;};
	DWORD   FeelChangeSurface(const FeelSurface& surface) {if(ftrChangeSurface) return ftrChangeSurface(surface) ;}
	//
	void   FeelSetCustomFeel(HWND hwnd,TCHAR* pstrControl) {if(ftrSetCSFeel) ftrSetCSFeel(hwnd,pstrControl) ;};
	void   FeelRemoveCustomFeel(HWND hwnd) {if(ftrRemoveCSFeel) ftrRemoveCSFeel(hwnd) ;}
	//frame
	void   FeelSetCustomFrameFeel(HWND hwnd,TCHAR* pstrControl) {if(ftrSetCSFrameFeel) ftrSetCSFrameFeel(hwnd,pstrControl) ;};
	void   FeelRemoveCustomFrameFeel(HWND hwnd) {if(ftrRemoveCSFrameFeel) ftrRemoveCSFrameFeel(hwnd) ;}
	//MenuBar
	void   FeelSetCustomMenuBarFeel(HWND hwnd,TCHAR* pstrControl) {if(ftrSetCSMenuBarFeel) ftrSetCSMenuBarFeel(hwnd,pstrControl) ;};
	void   FeelRemoveCustomMenuBarFeel(HWND hwnd) {if(ftrRemoveCSMenuBarFeel) ftrRemoveCSMenuBarFeel(hwnd) ;}
	//Scroll
	void   FeelSetCustomScrollFeel(HWND hwnd,TCHAR* pstrControl) {if(ftrSetCSScrollFeel) ftrSetCSScrollFeel(hwnd,pstrControl) ;};
	void   FeelRemoveCustomScrollFeel(HWND hwnd) {if(ftrRemoveCSScrollFeel) ftrRemoveCSScrollFeel(hwnd) ;}
	//Callback
	DWORD   FeelSetMouseCallee(HWND hwnd,TCHAR* pstrControl,TFeelMouseCallee* callee) {if(ftrSetMouseCallee) return ftrSetMouseCallee(hwnd,pstrControl,callee) ;};
	void   FeelRemoveMouseCallee(HWND hwnd) {if(ftrRemoveMouseCallee) ftrRemoveMouseCallee(hwnd) ;}
	//ANY
	DWORD   FeelRegisterProviderAny(const TCHAR* plugName,const _ProviderKeyAny& KeyAny) {if(ftrRegisterProviderAny) return ftrRegisterProviderAny(plugName,KeyAny) ;};
	void   FeelRemoveProviderAny(const TCHAR* plugName) {if(ftrRemoveProviderAny) ftrRemoveProviderAny(plugName) ;}
private:
	HMODULE m_hDll ;
	//PURE SYSTEM
	FeelSystem_AUTOSKIN        ftrautoSkin ;
	FeelSystem_REGEXTENDCLASS  ftrRegExtendClass ;
	FeelSystem_REGEXTENDCLASSFILE  ftrRegExtendClassFile;
	FeelSystem_REMOVEEXTENDCLASS   ftrRemoveExtendClass;
	FeelSystem_SETCSTHEME          ftrPureTheme;
	//FeelSystem
	FeelSystem_LOOKNFEELINIT       ftrSystemInit;
	FeelSystem_LOOKNFEELSTART      ftrSystemStart;
	FeelSystem_LOOKNFEELEND        ftrSystemEnd;
	FeelSystem_GETTHEMES           ftrGetThemes;
    FeelSystem_GETSURFACE          ftrGetSurfaces;
	FeelSystem_CHANGETHEME         ftrChangeTheme;
	FeelSystem_CHANGESURFACE       ftrChangeSurface;
	//
	FeelSystem_SETCSFEEL           ftrSetCSFeel;
	FeelSystem_REMOVECSFEEL        ftrRemoveCSFeel;
	//frame
	FeelSystem_SETCSFEEL           ftrSetCSFrameFeel;
	FeelSystem_REMOVECSFEEL        ftrRemoveCSFrameFeel;
	//Menubar
	FeelSystem_SETCSFEEL           ftrSetCSMenuBarFeel;
	FeelSystem_REMOVECSFEEL        ftrRemoveCSMenuBarFeel;
	//Scroll
	FeelSystem_SETCSFEEL           ftrSetCSScrollFeel;
	FeelSystem_REMOVECSFEEL        ftrRemoveCSScrollFeel;
	//callback
	FeelSystem_SETMOUSECALLEE       ftrSetMouseCallee;
	FeelSystem_REMOVEMOUSECALLEE    ftrRemoveMouseCallee;
	//ANY
	FeelSystem_REGISTERPROVIDERANY          ftrRegisterProviderAny;
	FeelSystem_REMOVEPROVIDERANY    ftrRemoveProviderAny;
};

inline BOOL MYFeelModule::Init(LPCTSTR DllPath)
{
	if(m_hDll)	return TRUE;
	m_hDll = ::LoadLibrary(DllPath);
	if(m_hDll == NULL)		return FALSE ;

	ftrautoSkin = (FeelSystem_AUTOSKIN) GetProcAddress(m_hDll, "SkinMain"); 
	if(!ftrautoSkin)	   
		return FALSE; 
	ftrRegExtendClass = (FeelSystem_REGEXTENDCLASS) GetProcAddress(m_hDll, "RegisterExtendClass"); 
	if(!ftrRegExtendClass)	   
		return FALSE; 
	ftrRegExtendClassFile= (FeelSystem_REGEXTENDCLASSFILE)GetProcAddress(m_hDll, "RegisterExtendClassFile"); 
	if(!ftrRegExtendClassFile)	   
		return FALSE; 
	ftrRemoveExtendClass= (FeelSystem_REMOVEEXTENDCLASS)GetProcAddress(m_hDll, "RemoveExtendClass"); 
	if(!ftrRemoveExtendClass)	
		return FALSE; 
	ftrPureTheme= (FeelSystem_SETCSTHEME)GetProcAddress(m_hDll, "SetCsTheme"); 
	if(!ftrPureTheme)	    
		return FALSE; 
  //FeelSystem
	ftrSystemInit= (FeelSystem_LOOKNFEELINIT)GetProcAddress(m_hDll, "FeelSystemInit"); 
	if(!ftrSystemInit)	    
		return FALSE; 
	ftrSystemStart= (FeelSystem_LOOKNFEELSTART)GetProcAddress(m_hDll, "FeelSystemStart"); 
	if(!ftrSystemStart)	    
		return FALSE; 
	ftrSystemEnd= (FeelSystem_LOOKNFEELEND)GetProcAddress(m_hDll, "FeelSystemEnd"); 
	if(!ftrSystemEnd)	    
		return FALSE; 		
	ftrGetThemes= (FeelSystem_GETTHEMES)GetProcAddress(m_hDll, "FeelSystemGetThemes"); 
	if(!ftrGetThemes)	  
		return FALSE; 
	ftrGetSurfaces= (FeelSystem_GETSURFACE)GetProcAddress(m_hDll, "FeelSystemGetSurfaces"); 
	if(!ftrGetSurfaces)	   
		return FALSE; 
	ftrChangeTheme= (FeelSystem_CHANGETHEME)GetProcAddress(m_hDll, "ChangeFeelTheme"); 
	if(!ftrChangeTheme)	    
		return FALSE; 
	ftrChangeSurface= (FeelSystem_CHANGESURFACE)GetProcAddress(m_hDll, "ChangeFeelSurface"); 
	if(!ftrChangeTheme)	    
		return FALSE; 
	ftrSetCSFeel= (FeelSystem_SETCSFEEL)GetProcAddress(m_hDll, "SetCustomFeel"); 
	if(!ftrSetCSFeel)	    
		return FALSE; 
	ftrRemoveCSFeel= (FeelSystem_REMOVECSFEEL)GetProcAddress(m_hDll, "RemoveCustomFeel"); 
	if(!ftrRemoveCSFeel)	    
		return FALSE; 
	//
	ftrSetCSFrameFeel= (FeelSystem_SETCSFEEL)GetProcAddress(m_hDll, "SetCustomFrameFeel"); 
	if(!ftrSetCSFrameFeel)	    
		return FALSE; 
	ftrRemoveCSFrameFeel= (FeelSystem_REMOVECSFEEL)GetProcAddress(m_hDll, "RemoveCustomFrameFeel"); 
	if(!ftrRemoveCSFeel)	    
		return FALSE; 
	//MenuBar
	ftrSetCSMenuBarFeel= (FeelSystem_SETCSFEEL)GetProcAddress(m_hDll, "SetCustomMenuBarFeel"); 
	if(!ftrSetCSMenuBarFeel)	    
		return FALSE; 
	ftrRemoveCSMenuBarFeel= (FeelSystem_REMOVECSFEEL)GetProcAddress(m_hDll, "RemoveCustomMenuBarFeel"); 
	if(!ftrRemoveCSMenuBarFeel)	    
		return FALSE; 
	//
	ftrSetCSScrollFeel= (FeelSystem_SETCSFEEL)GetProcAddress(m_hDll, "SetCustomScrollFeel"); 
	if(!ftrSetCSScrollFeel)	    
		return FALSE; 
	ftrRemoveCSScrollFeel= (FeelSystem_REMOVECSFEEL)GetProcAddress(m_hDll, "RemoveCustomScrollFeel"); 
	if(!ftrRemoveCSScrollFeel)	    
		return FALSE;
	//
	ftrSetMouseCallee= (FeelSystem_SETMOUSECALLEE)GetProcAddress(m_hDll, "RegisterFeelMouseCallee"); 
	if(!ftrSetMouseCallee)	    
		return FALSE; 
	ftrRemoveMouseCallee= (FeelSystem_REMOVEMOUSECALLEE)GetProcAddress(m_hDll, "RemoveFeelMouseCallee"); 
	if(!ftrRemoveMouseCallee)	    
		return FALSE; 
	//Any
	ftrRegisterProviderAny= (FeelSystem_REGISTERPROVIDERANY)GetProcAddress(m_hDll, "RegisterProviderAny"); 
	if(!ftrRegisterProviderAny)	    
		return FALSE; 
	ftrRemoveProviderAny= (FeelSystem_REMOVEPROVIDERANY)GetProcAddress(m_hDll, "RemoveProviderAny"); 
	if(!ftrRemoveProviderAny)	    
		return FALSE; 
	return TRUE ;
}
#endif