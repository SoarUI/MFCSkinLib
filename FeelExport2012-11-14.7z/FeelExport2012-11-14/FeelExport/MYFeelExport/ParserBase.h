#ifndef _ParserBase_h_
#define _ParserBase_h_
#include "../XMLHandler/XMLHandler.h"
class ParserBase
{
public:
	ParserBase(void){}
	virtual ~ParserBase(void){}
	virtual bool Parse(XMLHandler * handler,TCHAR* DataPtr,size_t size)=0;
	virtual void Release(void)=0;
	GString getIdentityString(void) {return d_identityString ;}
protected:
	GString d_identityString;
};
#endif