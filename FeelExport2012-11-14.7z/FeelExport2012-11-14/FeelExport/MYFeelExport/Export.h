#ifndef MYFeel_EXPORT_H
#define MYFeel_EXPORT_H
#include "GStringExport.h"
#include <vector>
// ��������
typedef enum EtgWindTYPE
{
	SKINT_UNKNOWN	        =	-1,	// ���ܴ���������,�������Ի��
	SKINT_PUSHBUTTON        =	0 ,	// ��ť
	SKINT_CHECKBOX	        = 	1	,// ��ѡ��
	SKINT_RADIOBOX	        =	2	,// ��ѡ��
	SKINT_GROUPBOX          =   3   ,//���
	SKINT_STATEBUTTON          =   4   ,//��̬��ť��δʹ��
	SKINT_EDITBOX	        =	5	,// �༭��
	SKINT_COMBOBOX	        =	6	,// ��Ͽ�
	SKINT_COMBOBOXEX32	    =	7	,// �����չ��
	SKINT_CBLISTBOX         =   8   ,//��Ͽ���listbox
	SKINT_STATIC            =   9   ,//STATIC
	SKINT_DIALOG            =   10   ,//DIALOG #32770
	SKINT_MENU              =   11   ,//#32768
	SKINT_SCROLLBAR         =   12  ,//��׼������
	SKINT_TREEVIEW          =   13  ,//treectrl
	SKINT_LISTVIEW          =   14  ,//listctrl
	SKINT_LISTBOX           =   15  ,//listbox
	SKINT_WEBBROWSER        =  16  ,//webbrowser
	SKINT_RICHEDIT          =  17  ,//richedit
	SKINT_TABCTRL           = 18 ,  //tabctrl
	SKINT_SLIDER            = 19 , //slider
	SKINT_SPIN              = 20 , //SPIN
	SKINT_IPADDRESS         = 21 ,//IPAddressCtrl
	SKINT_PROGRESS          = 22 ,//PROGRESS
	SKINT_HEADER32          = 23 ,//SysHeader32
	SKINT_HOTKEY32          = 24 ,//msctls_hotkey32
	SKINT_DATETIME32        = 25 ,//SysDateTimePick32
	SKINT_MONTHCTRL32       = 26 ,//SysMonthCal32
	SKINT_TOOLBAR32         = 27 ,//ToolbarWindow32
	SKINT_REBAR32           = 28 ,//ReBarWindow32
	SKINT_STATUSBAR         = 29 ,//msctls_statusbar
	//MFC
	SKINT_MDI               =30,//MDI
	SKINT_SDI              = 31 ,//SDI
	SKINT_MDICCLIENT       = 32 ,//MDIClient
	SKINT_FRAMEORVIEW      = 33 ,//AfxFrameOrView80ud
	SKINT_MDIFRAME         = 34 ,//AfxMDIFrame80ud,MDICLIENT
	SKINT_CONTROLBAR       = 35, //AfxControlBar80ud
	SKINT_END
}WindType;
typedef struct TtgSkinPureTheme
{
	//#default -Font
	DWORD _Default_Font_TYPE;
	DWORD _Default_Font_Size;
	//# global Text -color
	DWORD _Text_Color_Default ;
	DWORD _Text_Color_Hover ;
	DWORD _Text_Color_Disable ;
	//�ǿͻ������
	DWORD _NCBK_COLOR_Default; 
	DWORD _NCBK_COLOR_Hover;
	DWORD _NCBK_COLOR_Disable;
	//�߿����
	DWORD _FrameBorder_COLOR_Default;
	DWORD _FrameBorder_COLOR_Disable;
	DWORD _FrameBorder_COLOR_Hover;
	//���������
	DWORD _Titlebar_BK_COLOR_Default;
	DWORD _Titlebar_BK_COLOR_Disable;
	DWORD _Titlebar_BK_COLOR_Hover;
	//����������
	DWORD _Titlebar_Font_COLOR_Default;
	DWORD _Titlebar_Font_COLOR_Hover;
	DWORD _Titlebar_Font_COLOR_Disable;
	//����������λ��
	//�ͻ������
	DWORD _Client_COLOR_Default;
	DWORD _Client_COLOR_Disable;
	DWORD _Client_COLOR_Hover;
	//menubar
	DWORD _Menubar_Color_Default;
	DWORD _Menubar_Color_Disable;

	//menu
	DWORD _MenuItem_Color_Default;
	DWORD _MenuItem_Color_Disable;
	DWORD _MenuItem_Color_Hover;
	DWORD _MenuItem_FloodFill_Hover_Start;
	DWORD _MenuItem_FloodFill_Hover_End;
	//menu font
	DWORD _MenuItem_Font_Color_Disable;
	DWORD _MenuItem_Font_Color_Default;
	DWORD _MenuItem_Font_Color_Hover;
	//scrollbar
	DWORD _Scrollbar_Thunk_Color_Default;
	DWORD _Scrollbar_Thunk_Color_Disable;
	DWORD _Scrollbar_Button_Color_Default;
	DWORD _Scrollbar_Button_Color_Disable;
	DWORD _Scrollbar_Button_Color_Hover;
	DWORD _Scrollbar_Thumb_Color_Default;
	DWORD _Scrollbar_Thumb_Color_Disable;
	DWORD _Scrollbar_Thumb_Color_Hover;
	//��ͷ��ɫ
	DWORD _Scrollbar_Arrow_Color_Default;
	DWORD _Scrollbar_Arrow_Color_Disable;
	DWORD _Scrollbar_Arrow_Color_Hover;
	//һЩ��ƽ�����
	//titlebar
	DWORD _Titlebar_FloodFill_Default_Start;
	DWORD _Titlebar_FloodFill_Default_End;
	DWORD _Titlebar_FloodFill_Disable_Start;
	DWORD _Titlebar_FloodFill_Disable_End;
	//client
	DWORD _Client_FloodFill_Default_Start;
	DWORD _Client_FloodFill_Default_End;
	DWORD _Client_FloodFill_Disable_Start;
	DWORD _Client_FloodFill_Disable_End;
	DWORD _Client_FloodFill_Hover_Start;
	DWORD _Client_FloodFill_Hover_End;

}PureTheme,*PureThemePtr;
typedef struct TtgExtendClass
{
	TCHAR sSourceClass[100];
	//UINT uMask;
	WindType simulator;
}ExtWindType;
typedef std::vector<TtgExtendClass*> ExtendClassVector;
//�ų�
typedef struct TtgExcludeWindow
{
	TCHAR sSourceClass[100];
	UINT uMask;
	union excludor
	{
		TCHAR stdSkinClass[100];
		WindType stdSkinType;
	};
}ExcludeWindow;
typedef struct TtgFeelTheme
{
	GString d_name;
	GString d_helpString;
	GString d_smallTexture;
	GString d_group;
}FeelTheme,*FeelThemeFtr;
typedef std::vector<FeelTheme> FeelList;
//����Ϊ����
typedef struct TtgFeelSurface
{
	GString d_name;
	GString d_targettheme;
	GString d_smallTexture;
	GString d_targetTexture;
}FeelSurface,*FeelSurfaceFtr;
typedef std::vector<FeelSurface> FeelSurfaceList;
#endif