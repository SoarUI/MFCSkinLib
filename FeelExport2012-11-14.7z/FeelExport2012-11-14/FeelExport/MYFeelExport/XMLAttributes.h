
#ifndef _XMLAttributes_h_

#define _XMLAttributes_h_

#include "GStringExport.h"

#include <map>

    
class XMLAttributes
    {
   
 public:
        
       
 XMLAttributes(void);
        
virtual ~XMLAttributes(void);
		
void add(const GString& attrName, const GString& attrValue);
		
void remove(const GString& attrName);
		
bool exists(const GString& attrName) const;
		
size_t getCount(void) const;
		
const GString getName(size_t index) const;
		
const GString getValue(size_t index) const;
		
const GString getValue(const GString& attrName) const;
		
const GString getValueAsString(const GString& attrName, const GString& def = _T("")) const;
		
bool getValueAsBool(const GString& attrName, bool def = false) const;
		
int getValueAsInteger(const GString& attrName, int def = 0) const;
		
float getValueAsFloat(const GString& attrName, float def = 0.0f) const;

    
protected:
        
typedef std::map<GString, GString, GString::FastLessCompare> AttributeMap;
        
AttributeMap    d_attrs;
    
};

#endif  
