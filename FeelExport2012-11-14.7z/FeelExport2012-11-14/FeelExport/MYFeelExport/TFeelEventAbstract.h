#pragma once
/********************************************************************
    Descibe:      �¼��������࣬������MouseEvent 
    created:      2012/9/19 18:31
    FullName:     ..\MYFeel\MYFeel\TFeelEventAbstract.h
    Path:         ..\MYFeel\MYFeel
    ClassName:    TFeelEventAbstract
    FileType:     h
    Author:       nicklisir@163.com
    NeededLib:    
    requires:      
*********************************************************************/
#include "GStringExport.h"
#include "FeelEventstruct.h"
/*
0-MouseEvent
1-KeyEvent
*/
class TFeelEventAbstract
{
public:
	TFeelEventAbstract(void){;}
public:
	virtual ~TFeelEventAbstract(void){;}
	virtual UtgFeelEventID getEventID(void){ return d_EventID ;}
protected:
	UtgFeelEventID d_EventID;
};
