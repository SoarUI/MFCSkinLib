#ifndef _XMLHandler_h_
#define _XMLHandler_h_
#include "GStringExport.h"
#include "XMLAttributes.h"
class XMLHandler
{
public:
	XMLHandler(void){}
	virtual ~XMLHandler(void){}
	virtual void elementStart(const GString& element, const XMLAttributes& attributes)=0;
	virtual void elementEnd(const GString& element)=0;
	virtual void text(const GString& text)=0;
};
#endif