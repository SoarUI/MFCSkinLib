#ifndef _ProviderAny_h_
#define _ProviderAny_h_
#include "GStringExport.h"
typedef struct _ProviderKeyAny
{
	unsigned long d_Code;
	GString d_stringCode;
}ProviderAny,*KeyDataPtr;
#endif