#pragma  once
#include "GDFMACRO.h"
BEGIN_NAMSP
// the content here
enum eGDFSCROLL_TYPE
{
	E_TYPE_SCROLLBAR_V,//��ֱ������
	E_TYPE_SCROLLBAR_H
};
enum eGDFSCROLLBAR_ACTION
{
	E_BUTTON_ACTION_UP,
	E_BUTTON_ACTION_DOWN,
	E_BUTTON_ACTION_SCROLLLEFT,
	E_BUTTON_ACTION_SCROLLRIGHT
};
enum eSYSBUTTONTYPE
{
	E_TYPE_MIN,
	E_TYPE_MAX,
	E_TYPE_CLOSE,
	E_TYPE_OTHER
};//Ҫģ��İ�ť��
// CSkinListCtrl
enum eScrollbar
{
	E_BAR_NULL,
	E_BAR_V,
	E_BAR_H,
	E_BAR_BOTH
};
typedef struct _ITEM_NODE 
{
	CString szPath;
	/*_ITEM_NODE* pPrev;
	_ITEM_NODE*pNext*/
}ITEMNODE,*LPITEMNODE;
typedef struct _ITEM_NODE_POS 
{
	POSITION  CurPos;//��ǰλ��
	POSITION MinPos;//��Сλ��
	POSITION MaxPos;//���λ��
	int       cStep;      //�����,�ﵽ����ɾ��ǰһ��
}ITEMNODEPOS,*LPITEMNODEPOS;
// CGDFSkinListCtrl
// ------------------------------------------
//spector
//END_PROTECTH
END_NAMSP