#ifndef GDF_MACRO_H
#define GDF_MACRO_H
/********************************************************************
	copyright   nicklisir@163.com
    created:	2011/04/11
	created:	2011/4/11 11:35
	filename: 	e:\visual c++ projects\��ʽ�����\�����û��ಢ��Ԫ����\MGDFCoreLib\GDFMACRO.h
	file path:	e:\visual c++ projects\��ʽ�����\�����û��ಢ��Ԫ����\MGDFCoreLib
	file base:	MGDFMACRO
	file ext:	h
	author:		nicklisir
    email:      nicklisir@163.com
	LastUpdate  2011/04/11
	purpose:	the macro of the GDF lib,the MGDF is part of GDF base on MFC
*********************************************************************/
//the header file protect macro

//the GDF namespace macro
#define BEGIN_NAMSP                    namespace GDF_NAMSPK { 
#define END_NAMSP                      } 


#endif //end of file 