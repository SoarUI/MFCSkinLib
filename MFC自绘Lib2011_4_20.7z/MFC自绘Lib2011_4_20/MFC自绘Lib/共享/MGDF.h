
#pragma  once
#include "GDFMACRO.h"
#include "tchar.h"
#include "SkinConfig.h"
#include "GDFENUM.h"
#include "afxcmn.h"
#include <shlobj.h>
#pragma comment(lib, "shell32.lib") 
#include <Shlwapi.h> 
#pragma comment(lib, "shlwapi.lib")
BEGIN_NAMSP
//the content here
class AFX_EXT_CLASS CGDFGraphic
{
public:
	CGDFGraphic(VOID);
public:
	~CGDFGraphic(VOID);
	//����ͼƬ
	BOOL         LoadBitMap(HINSTANCE hInstance, LPCTSTR lpszBitmapName,
		                    UINT nCount,UINT width,UINT height,
		                    CPoint ptstat=CPoint(0,0),BOOL bOrientX=TRUE);//����λͼ�����ð�ť��С�͸߶�
	//�ⲿ����
	BOOL         SetBitMap(HBITMAP hbmp,UINT nCount,UINT width,UINT height,
		                   CPoint ptstat=CPoint(0,0),BOOL bOrientX=TRUE);

	//��������
	BOOL          SetText(CString szText);
	BOOL          SetTextClr(COLORREF clrtxt);
	BOOL          SetHoverClr(COLORREF clrhover);
	BOOL          ShowText(BOOL bShowText);
	VOID          SetTextFormat(UINT txtFormat);
	VOID          SetRect(CRect &rc);
	CRect         GetRect();
	VOID          SetState(INT eState);
	INT           GetState() const;
	UINT          GetWidth()const ;
	UINT          GetHeight()const ;
	UINT          GetbmWidth()const;
	UINT          GetbmHeight()const ;
	HBITMAP       GetBitMap() const throw();
	CPoint        GetImgIndex() const throw();
	//RTIT
	BOOL          HitTest(UINT &nFlags,const CPoint &pt) const{return TRUE;}//�����
	VOID          LButtonUp(UINT &nFlags,const CPoint &pt);
	VOID          LButtonDown(UINT &nFlags,const CPoint &pt);
	VOID          LButtonDoubleClick(UINT &nFlags,const CPoint &pt){}//˫��������
	virtual VOID MouseMove(UINT &nFlags,const CPoint &pt);
	virtual VOID CalcSize(const CRect &rc);//�����С������λ��
	virtual VOID Draw(CDC *pDC);//����
protected:
	virtual VOID DoDraw(CDC *pDC);//��������
protected:
	HBITMAP        m_hBitMap;//ͼ��,�������¼���
	CPoint         m_ptImgIndexStat;//ͼ����λͼ�еĿ�ʼ��
	CString        m_szText;//��ť����
	BOOL           m_bImg;//ͼ��ť
	BOOL           m_bOrientX;//ͼ�����з�ʽ
	BOOL           m_bOwnbmp;//�Ƿ�ӵ���Լ�λͼ
	UINT           m_nTextFormat;//���ַ�ʽ
	COLORREF       m_clrText;//������ɫ
	COLORREF       m_clrHoverText;//��꿿����ɫ
	UINT            m_nCount;//ͼ��֡��
	UINT            m_nWidthsrc,
		           m_nHeightsrc;//һ����ťλͼ�߶ȺͿ���
	UINT            m_nState;//״̬
	UINT            m_nAState;//����ʹ��[unused]
	//�������,�����Ǿ���..
	CRect          m_rcDraw;//
	UINT           m_nWidth,//��ť����
		           m_nHeight;//��ť�߶�
};
class AFX_EXT_CLASS CGDFGraphicComponent : public CGDFGraphic
{
public:
	CGDFGraphicComponent(CWnd *pParent=NULL);
public:
	~CGDFGraphicComponent(VOID);
public:
	//��������
	VOID           AttachWnd(CWnd *pParent);
	VOID           DetachWnd();
	VOID           Enable(BOOL bEnable);
	VOID           Show(BOOL bShow);
	//RTIT
	BOOL           HitTest(UINT &nFlags,const CPoint &pt) const;//�����
	BOOL           LButtonUp(UINT &nFlags,const CPoint &pt);
	BOOL           LButtonDown(UINT &nFlags,const CPoint &pt);
	BOOL           LButtonDoubleClick(UINT &nFlags,const CPoint &pt);//˫��������
	virtual VOID  MouseMove(UINT &nFlags,const CPoint &pt);
	virtual VOID  Draw(CDC *pDC);//����
	virtual VOID  CalcSize(const CRect &rc);//�����С������λ��
	virtual VOID  CalcSize(CPoint pos);//ͨ����������
protected:
	CPoint         m_ptPos;//����λ�ã����в�����������Ϊ�ο�
	BOOL           m_bEnable;//����/����
	BOOL           m_bShow;//�Ƿ���ʾ
	CWnd          *m_pParent;//������

};
class AFX_EXT_CLASS CGDFGraphicDependent :public CGDFGraphic
{
public:
	CGDFGraphicDependent(CWnd* pWnd=NULL);
	//����
	~CGDFGraphicDependent(VOID);
	BOOL          AttachWnd(CWnd* pWnd);
	VOID          DetachWnd();
	VOID          Draw(CDC *pDC);//��Ҫ���������ʹ��˫����
	VOID          LButtonDown(UINT nFlags, CPoint point);
	VOID          LButtonUp(UINT nFlags, CPoint point);
	VOID          MouseMove(UINT nFlags, CPoint point);
private:
	CWnd         *m_pWnd;//���ڻ�ȡ����

};

// CGDFScrollBar

class AFX_EXT_CLASS CGDFScrollBar : public CButton
{
	DECLARE_DYNAMIC(CGDFScrollBar)

public:
	CGDFScrollBar();
	virtual BOOL Create(eGDFSCROLL_TYPE dwStyle, const CRect& rect, CWnd* pParentWnd, UINT nID);
	virtual ~CGDFScrollBar();
	/////////////////////////////////����������λͼ����
	//�����ж�������һ��ͼ��ʱ��������
	BOOL                   LoadSkinBitMap(LPCTSTR pszPath,int srcbitmapWidth,int srcbitmapeight,BOOL bOrientX=TRUE);
	//���ù������ı���
	BOOL                   SetBackGround(LPCTSTR pszPath,int width,int height,BOOL bOrientX=TRUE);
	BOOL                   SetBackGround(HBITMAP hBitmap,int width,int height,CPoint &ptStat,BOOL bOrientX=TRUE);
	//���ù������Ļ���
	BOOL                   SetThumberbmp(LPCTSTR pszPath,int width,int height,BOOL bOrientX=TRUE);
	BOOL                   SetThumberbmp(HBITMAP hBitmap,int width,int height,CPoint &ptStat,BOOL bOrientX=TRUE);
	//���ù��������ϻ���ߵļ�ͷ��ť
	BOOL                   SetUpArrowbmp(LPCTSTR pszPath,int width,int height,BOOL bOrientX=TRUE);
	BOOL                   SetUpArrowbmp(HBITMAP hBitmap,int width,int height,CPoint &ptStat,BOOL bOrientX=TRUE);
	//���ù��������»��ұߵļ�ͷ��ť
	BOOL                   SetDownArrowbmp(LPCTSTR pszPath,int width,int height,BOOL bOrientX=TRUE);
	BOOL                   SetDownArrowbmp(HBITMAP hBitmap,int width,int height,CPoint &ptStat,BOOL bOrientX=TRUE);
	//////////////////////////////////���¹��ܺ���
	VOID                   SetScrollBarPos(CPoint &pt);
	VOID                   SetScrollBarPos(int x, int y);
	VOID                   SetScrollBarPos(CRect &rc);
	//��ȡ/���� ����λ��
	VOID                   UpdateThumber();
	//���ù�����
	BOOL                   EnableScrollBar(BOOL bEnable=TRUE) throw();
	//��ʾ�ؼ�
	BOOL                   ShowScrollBar(BOOL bShow=TRUE) throw();
	BOOL                   ShowWindow(int nCmdShow);
	//���������ؼ�
	BOOL                   SetHostControl(CListCtrl *pHostControl) throw();

	//��ȡ�������Χ
	INT                    SetScrollBarLimit(int nMax);
	VOID                   GetScrollBarLimit(int &nMax)const throw();
	//��ȡ��������
	eGDFSCROLL_TYPE        GetType(VOID) const throw();
	//��ȡͼ��
	HBITMAP                GetBitMap(VOID) const throw() ;
	//�ж��Ƿ�ﵽ����
	//�ж��Ƿ�ﵽ���
	BOOL                   IsMinized(CPoint &ptPos);
	//�ж��Ƿ�ﵽ�׶�
	//�ж��Ƿ񵽴��Ҷ�
	BOOL                   IsMaxized(CPoint &ptPos);

	//

	//��ʼ�����˻����
	BOOL                   InitTopLeft(VOID);
	//��ʼ���׶˻��Ҷ�
	BOOL                   InitBottomRight(VOID);
	//��ʼ������
	BOOL                   InitThumber(VOID);
	//��ʼ�����������
	VOID                   CalcInternal();
	//����
	virtual VOID          CalcSize(const CRect &rc);//�����С������λ��
	//�������������ϵļ�ͷ��ť��λ��,������m_pHostController��λ��
	virtual VOID          MoveUp();
	//�������������µļ�ͷ��ť��λ��,������m_pHostController��λ��
	virtual VOID          MoveDown();
	//��������������ļ�ͷ��ť��λ��,������m_pHostController��λ��
	virtual VOID          ScrollLeft();
	//�������������ҵļ�ͷ��ť��λ��,������m_pHostController��λ��
	virtual VOID          ScrollRight();
	virtual VOID          PageUp();
	virtual VOID          PageDown();
	virtual VOID          PageLeft();
	virtual VOID          PageRight();
	virtual VOID          Draw(CDC *pActualDC);//���ƹ�����
	//�Ȼ���������
	VOID                   PaintWnd(CDC *pDC);
	//���ư�ť
	VOID                   PaintButtons(CDC *pDC);
	DOUBLE                 GetHeight() const throw(){return m_dbHeight;};
	DOUBLE                 GetWidth()  const throw(){return m_dbWidth;};
	//���ػ��ຯ��
	VOID                   MoveWindow(int x, int y, int nWidth, int nHeight,
		                                  BOOL bRepaint = TRUE);
	VOID                   MoveWindow(LPCRECT lpRect, BOOL bRepaint = TRUE);
	BOOL                   SetWindowPos(const CWnd* pWndInsertAfter, int x, int y,
		                                 int cx, int cy, UINT nFlags);
protected:
	CGDFGraphic            m_graphic;//Ƥ��������
	CGDFGraphicComponent   m_rcTop;//���˻����
	CGDFGraphicComponent   m_rcBottom;//�׶˻��Ҷ�
	CGDFGraphicComponent   m_rcThumber;//����
	CGDFGraphicComponent   m_rcBKGRD;//��������
	eGDFSCROLL_TYPE        m_eType;//����������
	CRect                  m_rect;   //�ؼ�����
	BOOL                   m_bDragging;//������ק
	BOOL                   m_bMouseDown;//��갴��
	BOOL                   m_bInChannel;//�����ڹ�������Χ��
	BOOL                   m_bTopDown;//����ͷ����
	BOOL                   m_bBottomDown;//�׼�ͷ����
	BOOL                   m_bEnable;//ʹ��
	BOOL                   m_bShow;//enable to show window
	CPoint                 m_ptThumTop;//���鶥
	CListCtrl             *m_pHostControler;//������ʾ����
	DOUBLE                 m_dbHeight,
		                   m_dbWidth;//��������
	DOUBLE                 m_dbStep;//�ƶ���������
	
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg VOID OnPaint();
	afx_msg VOID OnMouseMove(UINT nFlags, CPoint point);
	afx_msg VOID OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg VOID OnLButtonUp(UINT nFlags, CPoint point);
public:
	//���ڸ��������߻���λ��
	afx_msg VOID OnTimer(UINT_PTR nIDEvent);
public:
	// ///
	VOID MiniMouseMove(CPoint &point);
};


class AFX_EXT_CLASS CSYSRectButton :
	public CGDFGraphicComponent
{
public:
	//struct and enum
public:
	CSYSRectButton(CWnd *pParent=NULL);
public:
	~CSYSRectButton(VOID);
	VOID                  SetButtonType(eSYSBUTTONTYPE eType);
	//�Լ�ӵ��λͼ��Դ
	BOOL                  LoadBitMap(HINSTANCE hInstance, LPCTSTR lpBitmapName,
		                             UINT nCount,UINT width,UINT height,CPoint ptstat=CPoint(0,0),
		                             CPoint ptRestorestat=CPoint(0,0),BOOL bOrientX=TRUE);//����λͼ�����ð�ť��С�͸߶�
	//û���Լ���λͼ��Դ
	BOOL                  SetBitMap(HBITMAP hbmp,UINT nCount,
		                            UINT width,UINT height,CPoint ptstat=CPoint(0,0),
		                            CPoint ptRestorestat=CPoint(0,0),BOOL bOrientX=TRUE);//�ⲿλͼ��Դ
	//��������
	//RTIT
	BOOL                  HitTest(UINT &nFlags,const CPoint &pt)const;//�����
	BOOL                  LButtonUp(UINT &nFlags,const CPoint &pt);
	BOOL                  LButtonDownd(UINT &nFlags,const CPoint &pt);
	BOOL                  LButtonDoubleClick(UINT &nFlags,const CPoint &pt);//˫��������
	VOID                  MouseMove(UINT &nFlags,const CPoint &pt);
	virtual VOID         Draw(CDC *pDC);//����
	virtual VOID         DrawRestore(CDC *pDC);
	virtual VOID         CalcSize(const CRect &rc);//�����С������λ��
protected:
	HBITMAP               m_hbmpRestore;//λͼ
	BOOL                  m_bRestore;//�ǻָ���ͼ
	eSYSBUTTONTYPE        m_eType;//����
	CPoint                m_ptRestorestat;//�ָ���ťͼ��ʼ��
};

class AFX_EXT_CLASS CSkinHeaderCtrl : public CHeaderCtrl
{
	DECLARE_DYNAMIC(CSkinHeaderCtrl)

public:
	CSkinHeaderCtrl();
	virtual ~CSkinHeaderCtrl();
	BOOL             CreateFont(int FontSize,LPCTSTR FontName);
	//���ظ߶�
	INT              GetHeight(){ CRect rc;GetClientRect(&rc);return (rc.bottom-rc.top); };
	COLORREF         SetTextColor(COLORREF textClr){ COLORREF tmpclr=m_clrText;m_clrText=textClr;return tmpclr; };
	COLORREF         GetTextColor(){return m_clrText;};
	//set the background bitmap
	VOID             LoadBKGRDBitmap(LPCTSTR bitmapName,int nCount,int nWidth,int nHeight,
		                             CPoint ptStat=CPoint(0,0),BOOL bOrientX=TRUE);
	VOID             SetBKGRDBitmap(HBITMAP hbitmap,int nCount,int nWidth,int nHeight,
		                            CPoint ptStat=CPoint(0,0),BOOL bOrientX=TRUE);
	//draw the BKGRD
	VOID             DrawBKGRD(CDC *pDC);
	//draw the text this function just for avoiding the same name to the system
	VOID             DrawTitle(CDC *pDC);
protected:
	CGDFGraphic            m_graphic;//Ƥ��������
	COLORREF               m_clrText;//������ɫ
	CFont                 *m_pFont;//����


protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg VOID OnPaint();
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};


class AFX_EXT_CLASS CGDFSkinListCtrl : public CListCtrl
{
	DECLARE_DYNAMIC(CGDFSkinListCtrl)

public:
	CGDFSkinListCtrl();
	virtual ~CGDFSkinListCtrl();
	BOOL                    Begin(__in DWORD HScrollbarID,__in DWORD VScrollbarID,
		                          eScrollbar ebar=E_BAR_BOTH,BOOL bLeftbar=FALSE);
	BOOL                    LoadHeaderCtrlParameter(LPCTSTR bitmapname,int nCount,int width,int height,
		                                           CPoint ptStat=CPoint(0,0),BOOL OrientX=TRUE,
		                                           LPCTSTR FontName=TEXT("����"),int FontSize=100);
	BOOL                    SetHeaderCtrlParameter(HBITMAP hbitmap,int nCount,int width,int height,
		                                            CPoint ptStat=CPoint(0,0),BOOL OrientX=TRUE,
		                                            LPCTSTR FontName=TEXT("����"),int FontSize=100);
	BOOL                    End();
	BOOL                    ShowWindow(int nCmdShow);//�޸�ԭ�к�����ʹ��������֮ͬ��
private:
	BOOL                    CreateScrollBar(BOOL bLeftScrollbar=FALSE);
protected:
	//������ʾ������
	virtual BOOL           CanShowHScroll();
	virtual BOOL           CanShowVScroll();
	//������ʹ��
	virtual BOOL           ShowScrollBar(eScrollbar ebar,BOOL bShow);
	virtual BOOL           ShowScrollBar(eScrollbar ebar);
	//
	VOID                    CreateHscrollBar(CRect &rc);
	VOID                    CreateVscrollBar(CRect &rc);
protected:
	CGDFScrollBar          *m_pVScroll,//��ֱ������
		                   *m_pHScroll;//ˮƽ������
	CSkinHeaderCtrl        *m_pheader;//��ͷ
	BOOL                    m_bLeftScrollbar;//��ֱ����������ߣ�Ĭ��ΪFALSE
	eScrollbar              m_eBar;//ӵ�й�������
	COLORREF                m_clrTxt,//������ɫ
		                    m_clrTxtBK,//���ֱ���
		                    m_clrHot;//����
	DWORD                   m_HScrollbarID,
		                    m_VScrollbarID;
	BOOL                    m_bHeaderInit;//���ڼ�¼�Ƿ��ʼ��HeaderCtrl
protected:
	DECLARE_MESSAGE_MAP()
	virtual VOID PreSubclassWindow();
public:
	//����λ�û��С�ı�ʱ
	afx_msg VOID OnWindowPosChanged(WINDOWPOS* lpwndpos);
	//��С�����ı�ʱ
	afx_msg VOID OnSize(UINT nType, int cx, int cy);
	afx_msg VOID OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS* lpncsp);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg VOID OnLvnDeleteitem(NMHDR *pNMHDR, LRESULT *pResult);
public:
	afx_msg VOID OnNcPaint();
};
class AFX_EXT_CLASS CGDFSkinDialog : public CDialog
{
	DECLARE_DYNAMIC(CGDFSkinDialog)

public:
	CGDFSkinDialog(CWnd* pParent = NULL);   // ��׼���캯��/***��Ϊ�����࣬����ֱ���޸�IDD����*/
	CGDFSkinDialog(UINT nIDTemplate,CWnd* pParent = NULL);//������Ӵ˹���
	virtual ~CGDFSkinDialog();

	// �Ի�������
	enum { IDD = 0 };//
protected:
	CSYSRectButton      m_rcBTNMax;
	CSYSRectButton      m_rcBTNMin;
	CSYSRectButton      m_rcBTNClose;
	UINT                m_uBorderHeight,//��Ե���
		                m_BottomHeight,//�ײ���
		                m_CaptionHeight;//����߲������߿�
	CGDFGraphic         m_graphic;//ͼ�������
protected:
	virtual VOID DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	//�ػ�ͻ���
	afx_msg VOID OnPaint();
	//�����
	afx_msg LRESULT OnNcHitTest(CPoint point);
	//�����ǿͻ�����Active
	afx_msg BOOL   OnNcActivate(BOOL bActive);
	afx_msg VOID   OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	//���÷ǿ����Ĵ�С
	afx_msg VOID   OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS* lpncsp);
	//�ػ�ǿͻ���
	afx_msg VOID   OnNcPaint();
	//˫��������
	afx_msg VOID   OnNcLButtonDblClk(UINT nHitTest, CPoint point);
	afx_msg VOID   OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg VOID   OnNcLButtonUp(UINT nHitTest, CPoint point);
	afx_msg VOID   OnNcMouseMove(UINT nHitTest, CPoint point);
	//��С�ı��
	afx_msg VOID   OnSize(UINT nType, int cx, int cy);
protected:
	virtual VOID  NCDraw(CDC *pDC);
	//�Ѵ���Ū��Ե��
	virtual VOID  CreateRoundWnd();
	// ����ϵͳ��ť
	virtual VOID  PaintSysButtons(CDC *pDC);
	// ���ƴ���
	virtual VOID  PaintWnd(CDC *pDC);

public:
	virtual BOOL  OnInitDialog();
	virtual VOID  EnableMaxiMize(BOOL bEnable);//�������
	virtual VOID  EnableMiniMize(BOOL bEnable);//������С��
	virtual VOID  EnableSYSClose(BOOL bEnable);//����رհ�ť
	//��������ʾ����
	virtual VOID  ShowMaxiMize(BOOL bShow);
	virtual VOID  ShowMiniMize(BOOL bShow);
	virtual VOID  ShowSYSClose(BOOL bShow);
protected:
	//���໯��
	virtual VOID  PreSubclassWindow();
	//������Ϣ������HOOK
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	VOID SetHook();//just for later extend [nouse]
	VOID DeleteHook();//just for later extend [nouse]
public:
	afx_msg VOID  OnClose();
	afx_msg VOID  OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	afx_msg BOOL  OnEraseBkgnd(CDC* pDC);
};

class AFX_EXT_CLASS CSkinListIconCtrl :
	public CGDFSkinListCtrl
{
public:
	CSkinListIconCtrl(VOID);
public:
	~CSkinListIconCtrl(VOID);
	VOID EnableBarIgnoreSize(BOOL bEnableBar);//�������ҲҪ��ʾ������
protected:
	//������ʾ������
	virtual BOOL CanShowHScroll();
	virtual BOOL CanShowVScroll();
private:
	BOOL             m_bEnSureBar;//������ζ���ʾ������
	DECLARE_MESSAGE_MAP()
	afx_msg VOID OnNMCustomdraw(NMHDR *pNMHDR, LRESULT *pResult);//�Ի�
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);//����
};

class AFX_EXT_CLASS CSkinListReportCtrl : public CGDFSkinListCtrl
{
	DECLARE_DYNAMIC(CSkinListReportCtrl)

public:
	CSkinListReportCtrl();
	virtual ~CSkinListReportCtrl();
	VOID EnableBarIgnoreSize(BOOL bEnableBar);//�������ҲҪ��ʾ������
protected:
	//������ʾ������
	virtual BOOL CanShowHScroll();
	virtual BOOL CanShowVScroll();
	//
private:
	BOOL             m_bEnSureBar;//������ζ���ʾ������
protected:
	DECLARE_MESSAGE_MAP()
public:
	//afx_msg VOID OnPaint();
	VOID  EnableHighlighting(HWND hWnd, int row, BOOL bHighlight);
	BOOL  IsRowSelected(HWND hWnd, int row);
	BOOL  IsRowHighlighted(HWND hWnd, int row);
public:
	//���ڱ���
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg VOID OnCustomDraw ( NMHDR* pNMHDR, LRESULT* pResult );

};


class AFX_EXT_CLASS CGDFEdit : public CEdit
{
	DECLARE_DYNAMIC(CGDFEdit)

public:
	CGDFEdit();
	virtual ~CGDFEdit();
	BOOL                     LoadBitMap(LPCTSTR bitMapName,int nCount,
		                                int width,int height ,CPoint ptStat,BOOL bOrientX=TRUE);
	BOOL                     SetBitMap(HBITMAP hbitmap,int nCount,
		                              int width,int height,CPoint ptStat,BOOL bOrientX=TRUE);
	BOOL                     SetText(CString szText);
	BOOL                     SetTextClr(COLORREF clrtxt);
	BOOL                     SetHoverClr(COLORREF clrhover);
	BOOL                     ShowText(BOOL bShowText);
private:
	CGDFGraphicDependent     m_Graphic;
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg VOID OnPaint();
	afx_msg VOID OnEnSetfocus();
public:
	afx_msg VOID OnMouseMove(UINT nFlags, CPoint point);
public:
	afx_msg VOID OnSetFocus(CWnd* pOldWnd);
public:
	afx_msg VOID OnLButtonDblClk(UINT nFlags, CPoint point);
};

class AFX_EXT_CLASS CListEdit : public CGDFEdit
{
	DECLARE_DYNAMIC(CListEdit)

public:
	CListEdit();
	virtual ~CListEdit();
	CString   GetString() const;
	VOID      SetString(CString &szNewString) throw();
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg VOID OnEnKillfocus();
private:
	CString   m_szString;//�洢����
	afx_msg VOID OnKillFocus(CWnd* pNewWnd);
	afx_msg VOID OnSetFocus(CWnd* pOldWnd);
};

class AFX_EXT_CLASS CGDFComBo : public CComboBox
{
	DECLARE_DYNAMIC(CGDFComBo)

public:
	CGDFComBo();
	virtual ~CGDFComBo();
	BOOL Begin();
	BOOL End();
	VOID LoadBKGRNDBitMap(LPCTSTR bitMapName,int nCount,int width,int height ,CPoint ptStat,BOOL bOrientX=TRUE);
	VOID SetBKGRNDBitMap(HBITMAP hbitmap,int nCount,int width,int height,CPoint ptStat,BOOL bOrientX=TRUE);
	VOID LoadTriangleBitMap(LPCTSTR bitMapName,int nCount,int width,int height ,CPoint ptStat,BOOL bOrientX=TRUE);
	VOID SetTriangleBitMap(HBITMAP hbitmap,int nCount,int width,int height,CPoint ptStat,BOOL bOrientX=TRUE);
	VOID LoadDropDownBitMap(LPCTSTR bitMapName,int nCount,int width,int height,CPoint ptStat ,BOOL bOrientX=TRUE);
	VOID SetDropDownBitMap(HBITMAP hbitmap,int nCount,int width,int height,CPoint ptStat,BOOL bOrientX=TRUE);
	VOID SetItemHeight(UINT cyItemHeight);
protected:
	virtual VOID DrawTrignle(CDC *pDC);
protected:
	CGDFGraphicDependent    m_BKGRND;//����
	CGDFGraphicComponent    m_triangle;//ѡ������
	CGDFGraphicComponent    m_BKGRNDItem;//���
	CPtrList                m_ItemList;//���б�
	INT                     m_nItemHeight;  
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg VOID OnPaint();
	afx_msg VOID OnMouseMove(UINT nFlags, CPoint point);
	afx_msg VOID OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg VOID OnLButtonUp(UINT nFlags, CPoint point);
protected:
	virtual VOID PreSubclassWindow();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual VOID MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
public:
	virtual VOID DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual int CompareItem(LPCOMPAREITEMSTRUCT lpCompareItemStruct);
};


class AFX_EXT_CLASS CExLabel : public CStatic
{
	// Construction
public:
	CExLabel();
private:
	//copy control
	CExLabel& operator=(const CExLabel &rhs);
public:
	VOID SetTextClr(COLORREF color);
	VOID SetURL(CString szURL);
	VOID SetHoverClr(COLORREF clrHover);
	VOID GetURL(CString &szURL) const;
	VOID SetText(CString szText);
	virtual ~CExLabel();

protected:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	DECLARE_MESSAGE_MAP()
private:
	COLORREF   m_ClrText;//������ɫ
	COLORREF   m_ClrHover;//
	CString    m_szURL;//��ַ
	CString    m_szText;
	BOOL       m_bHover;
	HCURSOR    m_hCursor;//�����״
protected:
	virtual VOID PreSubclassWindow();
public:
	afx_msg VOID OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg VOID OnMouseMove(UINT nFlags, CPoint point);
public:
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
public:
	afx_msg VOID OnPaint();
};
class AFX_EXT_CLASS CBMPButton : public CButton
{
	DECLARE_DYNAMIC(CBMPButton)

public:
	CBMPButton();
	virtual ~CBMPButton();
	BOOL LoadBitMap(LPCTSTR bitMapName,int nCount,int width,int height ,CPoint ptStat,BOOL bOrientX=TRUE);
	BOOL SetBitMap(HBITMAP hbitmap,int nCount,int width,int height,CPoint ptStat,BOOL bOrientX=TRUE);
	BOOL SetText(CString szText);
	BOOL SetTextClr(COLORREF clrtxt);
	BOOL SetHoverClr(COLORREF clrhover);
	BOOL ShowText(BOOL bShowText);
protected:
	DECLARE_MESSAGE_MAP()
protected:
	CGDFGraphicDependent m_Graphic;//ͼ����ع�����
public:
	afx_msg VOID OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg VOID OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg VOID OnMouseMove(UINT nFlags, CPoint point);
	afx_msg VOID OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};
// CSkinFileDialog �Ի���

class AFX_EXT_CLASS CSkinFileDialog : public CGDFSkinDialog
{
	DECLARE_DYNAMIC(CSkinFileDialog)

public:
	 explicit CSkinFileDialog(BOOL bOpenFileDialog, // ���� FileOpen Ϊ TRUE������ FileSaveAs Ϊ FALSE
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		BOOL bAllowMultiSelected=TRUE,
		LPCTSTR lpszFilter = NULL,//Ĭ��Ϊ�ļ��У���NULLΪ�ļ�
		CWnd* pParentWnd = NULL);   // ��׼���캯��
	virtual ~CSkinFileDialog();
	virtual  VOID     FileChanged();
	virtual  VOID     FolderChanged(LPNMLISTVIEW pNMListView);
	CString            GetExt(CString & szFileName);
	BOOL               IsFolder(CString &szFileName);
	BOOL               IsFolder1(CString &szFileName);
	BOOL               IsFolder2(CString &szFileName);
	BOOL               IsFolderAndExit(CString &szFileName);//���ڲ����ļ���
	BOOL               IsFolederSure(CString &szFileName);//�����ϸ��
private:
	BOOL               InternalInit();//�ڲ���ʼ��
	BOOL               InternalInitImageList();//�ڲ���ʼ��ͼ���б�
	CString            GetFilterExt();//����ѡ�еĹ����ַ���
	BOOL               EnableUpButton();//�������ϰ�ť�����
	CString            GetSelectedItem(int &RselectedItem);//��ȡѡ����
	VOID               DeleteDirectory(CString sDirName);
public:
	//��ѡ����
	POSITION           GetStartPosition();
	CString            GetNextPathName(POSITION &pos);
protected:
	VOID              UpWard();//������һ��Ŀ¼
	VOID              BackWard();//������һ�����
	VOID              ForeWard();//��һ��
	VOID              NewFolder(CString szName);//�½�Ŀ¼
	VOID              DoReName(CString szOldName,CString szNewName);//������
	VOID              AddToBackList(CString &szDirStr);//��·�����ӽ��б���
	VOID              FindString(CString& szPath,CString &szRet);//����()�ڵ��ӷ���
	VOID              FindChild(CString szPath,CString szFilter=TEXT("*.*"));//��Ӧ��Ŀ¼ 
	//����·����ȡϵͳͼ��
	int               GetSysIcon(CString szPath,BOOL bIsDir);//
	// �Ի�������
	UINT              IDD ;
private:
	CString           m_szFilter;//�ļ�����
	CString           m_szPrevPath;//��ǰ����һ·��
	CString           m_szCurPath;//��ǰ·��
	CString           m_szlpRoot;//
	CString           m_szFileList;//��ǰѡ���б���
	BOOL              m_bFileOpen;//
	BOOL              m_bSingleSelected;//��ѡ���
	CImageList        m_ImageList;//ͼ���б�
	//����������һ������
	CPtrList         *m_pBackList;//��������
	LPITEMNODEPOS     m_pBackPos;//��¼����λ�÷�����
	BOOL              m_bNewFolder;
	BOOL              m_bReName;//������
	BOOL              m_bDoModel;//������Ƿ񾭹�WM_INITDialog
public:
	// ��Χ
	CGDFComBo         m_ComBoScope;
	// ����
	CGDFComBo         m_ComBoFilter;
	// ����ʾ��

	CSkinListIconCtrl m_DlgList;
	// ��ǰѡ��
	CListEdit         m_EditCur;
	// ȷ����ť
	CBMPButton        m_OK;
	// ȡ����ť
	CBMPButton        m_Cancel;
	// ���ذ�ť
	CBMPButton        m_STBack;
	//CSKinButtonST m_STBack;
	// ǰ��
	CBMPButton        m_STForeWard;
	//CSKinButtonST m_STForeWard;
	// ��һ����ť
	CBMPButton        m_STUp;
	//CSKinButtonST  m_STUp;
	// �½��ļ��а�ť
	CBMPButton        m_STNewFolder;
	//CSKinButtonST m_STNewFolder;
	// ����
	//CExLabel m_STAuthor;
	// ��Χ
	CExLabel          m_LSCOPE;
	// ��ǰѡ��
	CExLabel          m_LCur;
	// �ļ�����
	CExLabel          m_LFilter;
protected:
	virtual VOID DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();

public:
	afx_msg VOID OnCbnSelendokFiledlgcomboscope();
	afx_msg VOID OnCbnSelendokFiledlgcombofilter();
public:
	////ĳ�����Ѿ������仯
	afx_msg VOID OnLvnItemchangedFiledlglist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg VOID OnNMClickFiledlglist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg VOID OnNMDblclkFiledlglist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg VOID OnNMRclickFiledlglist(NMHDR *pNMHDR, LRESULT *pResult);
public:
	afx_msg VOID OnStnClickedFiledlgstback();
	afx_msg VOID OnStnClickedStforedward();
	afx_msg VOID OnStnClickedFiledlgstup();
public:
	afx_msg VOID OnRmfiledel();
	afx_msg VOID OnRmfileopen();
	afx_msg VOID OnRmfilerename();
	afx_msg VOID OnRmfileselect();
public:
	afx_msg VOID OnRmfolderdel();
	afx_msg VOID OnRmfolderopen();
	afx_msg VOID OnRmfolderrename();
	afx_msg VOID OnRmfolderselect();
public:
	afx_msg VOID OnBnClickedFiledlgstback();

public:
	afx_msg VOID OnBnClickedFiledlgstnewfolder();

public:
	afx_msg VOID OnEnKillfocusFiledlgcuredit();

};

class AFX_EXT_CLASS CGDFFrameWnd : public CFrameWnd
{
	DECLARE_DYNCREATE(CGDFFrameWnd)
public:
	CGDFFrameWnd();           // ���캯��
	virtual ~CGDFFrameWnd();
	virtual BOOL InitWnd();
	virtual VOID  EnableMaxiMize(BOOL bEnable);//�������
	virtual VOID  EnableMiniMize(BOOL bEnable);//������С��
	virtual VOID  EnableSYSClose(BOOL bEnable);//����رհ�ť
	//��������ʾ����
	virtual VOID  ShowMaxiMize(BOOL bShow);
	virtual VOID  ShowMiniMize(BOOL bShow);
	virtual VOID  ShowSYSClose(BOOL bShow);
protected:
	virtual VOID  NCDraw(CDC *pDC);
	// ����ϵͳ��ť
	virtual VOID  PaintSysButtons(CDC *pDC);
	// ���ƴ���
	virtual VOID  PaintWnd(CDC *pDC);
	virtual VOID  PaintTitle(CDC *pDC);
	virtual VOID  PaintIcon(CDC * pDC);
	//virtual void  DrawTransparent(CDC* pDC,COLORREF clrTransparent);
protected:
	CSYSRectButton           m_rcBTNMax;
	CSYSRectButton           m_rcBTNMin;
	CSYSRectButton           m_rcBTNClose;
	UINT                     m_uBorderHeight,//��Ե���
		                     m_BottomHeight,//�ײ���
		                     m_CaptionHeight;//����߲������߿�
	CGDFGraphic              m_graphic;//ͼ�������
	HICON                    m_hIcon;
protected:
	DECLARE_MESSAGE_MAP()
	virtual void PreSubclassWindow();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
public:
	//��С�����ı�
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//��������
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//
	afx_msg void OnInitMenu(CMenu* pMenu);
	//����ͻ���
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS* lpncsp);
	//�����
	afx_msg LRESULT OnNcHitTest(CPoint point);
	//���˫��
	afx_msg void OnNcLButtonDblClk(UINT nHitTest, CPoint point);
	//�������
	afx_msg void OnNcLButtonUp(UINT nHitTest, CPoint point);
	//����ƶ�
	afx_msg void OnNcMouseMove(UINT nHitTest, CPoint point);
public:
	afx_msg void OnNcPaint();
protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
public:
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
public:
	afx_msg BOOL OnNcActivate(BOOL bActive);
public:
	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
protected:
	virtual void OnUpdateFrameMenu(HMENU hMenuAlt);
public:
	afx_msg BOOL OnNcCreate(LPCREATESTRUCT lpCreateStruct);
public:
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
public:
	afx_msg void OnPaint();
};

//////////////////////////////////////////////////////////////////////////
//the inline functions
inline VOID CGDFGraphic::SetRect(CRect &rc)
{
	m_rcDraw=rc;
	m_nWidth=rc.Width();
	m_nHeight=rc.Height();
}
inline CRect CGDFGraphic::GetRect()
{
	return m_rcDraw;
}
inline BOOL CGDFGraphic::SetText(CString szText)
{
	m_szText=szText;
	return TRUE;
}
inline BOOL CGDFGraphic::SetTextClr(COLORREF clrtxt)
{
	m_clrText=clrtxt;
	return TRUE;
}
inline BOOL CGDFGraphic::SetHoverClr(COLORREF clrhover)
{
	m_clrHoverText=clrhover;
	return TRUE;
}
inline BOOL CGDFGraphic::ShowText(BOOL bShowText)
{
	m_bImg=!bShowText;
	return TRUE;
}
inline VOID CGDFGraphic::SetTextFormat(UINT txtFormat)
{
	m_nTextFormat=txtFormat;
}
inline VOID  CGDFGraphic::SetState(INT nState)
{
	m_nState=nState;
}
inline INT CGDFGraphic::GetState() const
{
	return m_nState;
}
inline UINT CGDFGraphic::GetWidth()const
{
	return m_nWidth;
}
inline UINT CGDFGraphic::GetHeight()const 
{
	return m_nHeight;
}
inline UINT CGDFGraphic::GetbmWidth()const
{
	return m_nWidthsrc;
}
inline UINT CGDFGraphic::GetbmHeight()const 
{
	return m_nHeightsrc;
}
inline HBITMAP CGDFGraphic::GetBitMap() const throw()
{
	if (m_hBitMap)
	{
		return m_hBitMap;
	}
	else
	{
		return NULL;
	}
}
inline CPoint  CGDFGraphic::GetImgIndex() const throw()
{
	return m_ptImgIndexStat;
}
inline VOID CGDFGraphic::CalcSize(const CRect &rc)//�����С������λ��
{
	m_rcDraw=rc;
	m_nHeight=rc.Height();
	m_nWidth=rc.Width();
}
//------------------------------------------------------------------------------
//CGDFGraphicComponent
inline VOID  CGDFGraphicComponent::AttachWnd(CWnd *pParent)
{
	m_pParent=pParent;
}
inline VOID  CGDFGraphicComponent::DetachWnd()
{
	m_pParent=NULL;
}
inline VOID  CGDFGraphicComponent::Enable(BOOL bEnable)
{
	m_bEnable=bEnable;
}
inline VOID  CGDFGraphicComponent::Show(BOOL bShow)
{
	m_bShow=bShow;
}
//----------------------------------------------------------------------------------
inline BOOL CGDFGraphicDependent::AttachWnd(CWnd* pWnd)
{
	ASSERT(pWnd!=NULL);
	if (NULL==m_pWnd)
	{
		m_pWnd=pWnd;
	}else
	{
		return FALSE;
	}

	return TRUE;
}
inline VOID CGDFGraphicDependent::DetachWnd()
{
	//ASSERT(m_pWnd!=NULL);
	m_pWnd=NULL;
}
// ------------------------------------------
//CGDFSkinListCtrl
inline BOOL CGDFSkinListCtrl::ShowWindow(int nCmdShow)//�޸�ԭ�к�����ʹ��������֮ͬ��
{
	//״̬��ʾ
	ShowScrollBar(E_BAR_BOTH);
	return CListCtrl::ShowWindow(nCmdShow);
}
inline BOOL CGDFSkinListCtrl::CanShowHScroll()
{
	return TRUE;
}
inline BOOL CGDFSkinListCtrl::CanShowVScroll()
{
	return TRUE;
}
// ------------------------------------------
//CGDFSkinDialog
inline VOID CGDFSkinDialog::EnableMaxiMize(BOOL bEnable)
{
	m_rcBTNMax.Enable(bEnable);
}
inline VOID CGDFSkinDialog::EnableMiniMize(BOOL bEnable)
{
	m_rcBTNMin.Enable(bEnable);
}
inline VOID CGDFSkinDialog::EnableSYSClose(BOOL bEnable)
{
	m_rcBTNClose.Enable(bEnable);
}
//��������ʾ����
inline VOID CGDFSkinDialog::ShowMaxiMize(BOOL bShow)
{
	m_rcBTNMax.Show(bShow);
}
inline VOID CGDFSkinDialog::ShowMiniMize(BOOL bShow)
{
	m_rcBTNMin.Show(bShow);
}
inline VOID CGDFSkinDialog::ShowSYSClose(BOOL bShow)
{
	m_rcBTNClose.Show(bShow);
}
// ------------------------------------------
//CSkinListIconCtrl
inline VOID CSkinListIconCtrl::EnableBarIgnoreSize(BOOL bEnSureBar)
{
	m_bEnSureBar=bEnSureBar;
}
// ------------------------------------------
//CSkinListReport
inline VOID CSkinListReportCtrl::EnableBarIgnoreSize(BOOL bEnSureBar)
{
	m_bEnSureBar=bEnSureBar;
}
// ------------------------------------------
//CGDFEdit
inline BOOL  CGDFEdit::LoadBitMap(LPCTSTR bitMapName,int nCount,int width,int height ,CPoint ptStat,BOOL bOrientX)
{
	return m_Graphic.LoadBitMap(NULL,bitMapName,nCount,width,height,ptStat,bOrientX);
}
inline BOOL  CGDFEdit::SetBitMap(HBITMAP hbitmap,int nCount,int width,int height,CPoint ptStat,BOOL bOrientX)
{
	return m_Graphic.SetBitMap(hbitmap,nCount,width,height,ptStat,bOrientX);
}
inline BOOL  CGDFEdit::SetText(CString szText)
{
	return m_Graphic.SetText(szText);
}
inline BOOL  CGDFEdit::SetTextClr(COLORREF clrtxt)
{
	return m_Graphic.SetTextClr(clrtxt);
}
inline BOOL  CGDFEdit::SetHoverClr(COLORREF clrhover)
{
	return m_Graphic.SetHoverClr(clrhover);
}
inline BOOL  CGDFEdit::ShowText(BOOL bShowText)
{
	return m_Graphic.ShowText(bShowText);
}
// ------------------------------------------
//CListEdit
inline CString CListEdit::GetString() const
{
	return m_szString;
}
// ------------------------------------------
//CGDFComBo
inline VOID CGDFComBo::LoadBKGRNDBitMap(LPCTSTR bitMapName,int nCount,
										int width,int height ,CPoint ptStat,BOOL bOrientX)
{
	m_BKGRND.LoadBitMap(NULL,bitMapName,nCount,width,height,ptStat,bOrientX);
	m_BKGRND.ShowText(FALSE);
}
inline VOID CGDFComBo::SetBKGRNDBitMap(HBITMAP hbitmap,int nCount,int width,int height,
									   CPoint ptStat,BOOL bOrientX)
{
	m_BKGRND.SetBitMap(hbitmap,nCount,width,height,ptStat,bOrientX);
	m_BKGRND.ShowText(FALSE);
}
inline VOID CGDFComBo::LoadTriangleBitMap(LPCTSTR bitMapName,int nCount,int width,int height ,
										  CPoint ptStat,BOOL bOrientX)
{
	m_triangle.LoadBitMap(GetModuleHandle(NULL),bitMapName,nCount,width,height,ptStat,bOrientX);
}
inline VOID CGDFComBo::SetTriangleBitMap(HBITMAP hbitmap,int nCount,int width,int height,
										 CPoint ptStat,BOOL bOrientX)
{
	m_triangle.SetBitMap(hbitmap,nCount,width,height,ptStat,bOrientX);
}
inline VOID CGDFComBo::LoadDropDownBitMap(LPCTSTR bitMapName,int nCount,int width,int height 
										  ,CPoint ptStat,BOOL bOrientX)
{
	m_BKGRNDItem.LoadBitMap(GetModuleHandle(NULL),bitMapName,nCount,width,height,ptStat,bOrientX);
}
inline VOID CGDFComBo::SetDropDownBitMap(HBITMAP hbitmap,int nCount,int width,int height,
										 CPoint ptStat,BOOL bOrientX)
{
	m_BKGRNDItem.SetBitMap(hbitmap,nCount,width,height,ptStat,bOrientX);
}
inline VOID CGDFComBo::SetItemHeight(UINT cyItemHeight)
{
	m_nItemHeight=cyItemHeight;
}
// ------------------------------------------
//FileDialog
//��ѡ����
inline POSITION CSkinFileDialog::GetStartPosition()
{
	if (m_szFileList.IsEmpty()&&!m_szFilter.IsEmpty())
	{
		return NULL;
	}
	return (POSITION)m_szFileList.GetBuffer();
}
// ------------------------------------------
//CExLabel
inline VOID CExLabel::SetTextClr(COLORREF color)
{
	m_ClrText=color;
}
inline VOID CExLabel::SetURL(CString szURL)
{
	m_szURL=szURL;
}
inline VOID CExLabel::SetHoverClr(COLORREF clrHover)
{
	m_ClrHover=clrHover;
}
inline VOID CExLabel::GetURL(CString &szURL) const
{
	szURL=m_szURL;
}
inline VOID CExLabel::SetText(CString szText)
{
	m_szText=szText;
}
// ------------------------------------------
//CBMPButton
inline BOOL CBMPButton::LoadBitMap(LPCTSTR bitMapName, int nCount, int width, int height, CPoint ptStat, BOOL bOrientX )
{
	return m_Graphic.LoadBitMap(NULL,bitMapName,nCount,width,height,ptStat,bOrientX);
}
inline BOOL CBMPButton::SetBitMap(HBITMAP hbitmap, int nCount, int width, int height, CPoint ptStat, BOOL bOrientX)
{
	return m_Graphic.SetBitMap(hbitmap,nCount,width,height,ptStat,bOrientX);
}
inline BOOL CBMPButton::SetText(CString szText)
{
	return m_Graphic.SetText(szText);
}
inline BOOL CBMPButton::SetTextClr(COLORREF clrtxt)
{
	return m_Graphic.SetTextClr(clrtxt);
}
inline BOOL CBMPButton::SetHoverClr(COLORREF clrhover)
{
	return m_Graphic.SetHoverClr(clrhover);
}
inline BOOL CBMPButton::ShowText(BOOL bShowText)
{
	return m_Graphic.ShowText(bShowText);
}

// ------------------------------------------
//NULL
// ------------------------------------------
//CGDFFrameWnd
inline VOID CGDFFrameWnd::EnableMaxiMize(BOOL bEnable)
{
	m_rcBTNMax.Enable(bEnable);
}
inline VOID CGDFFrameWnd::EnableMiniMize(BOOL bEnable)
{
	m_rcBTNMin.Enable(bEnable);
}
inline VOID CGDFFrameWnd::EnableSYSClose(BOOL bEnable)
{
	m_rcBTNClose.Enable(bEnable);
}
//��������ʾ����
inline VOID CGDFFrameWnd::ShowMaxiMize(BOOL bShow)
{
	m_rcBTNMax.Show(bShow);
}
inline VOID CGDFFrameWnd::ShowMiniMize(BOOL bShow)
{
	m_rcBTNMin.Show(bShow);
}
inline VOID CGDFFrameWnd::ShowSYSClose(BOOL bShow)
{
	m_rcBTNClose.Show(bShow);
}
//END_PROTECTH//end of header protected
END_NAMSP //end of namespace gdf