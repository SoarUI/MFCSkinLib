#include "GDFMACRO.h"
#ifndef GDF_MFC
#define GDF_MFC
#endif 
BEGIN_NAMSP
// ------------------------------------------
//head file begin
#include "SkinConfig.h"
#ifdef GDF_MFC
#include "MGDF.h"
#else
#include "SGDF.h"
#endif

// ------------------------------------------
//namespace end
END_NAMSP